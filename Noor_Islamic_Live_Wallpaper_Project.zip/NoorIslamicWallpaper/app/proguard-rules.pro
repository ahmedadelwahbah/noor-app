# Keep Adhan library classes
-keep class com.batoulapps.adhan.** { *; }
-keep class com.noor.islamicwallpaper.** { *; }
