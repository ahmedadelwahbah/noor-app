package com.noor.islamicwallpaper;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * يستجيب لإعادة تشغيل الهاتف وتغير الوقت والمنطقة الزمنية والتاريخ
 * ليقوم بتحديث أداة الشاشة الرئيسية (Widget) ومواقيت الصلاة تلقائياً.
 */
public class BootAndTimeReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null) return;
        NoorAppWidgetProvider.updateAllWidgets(context);
    }
}
