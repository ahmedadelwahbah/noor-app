package com.noor.islamicwallpaper;

import com.batoulapps.adhan.CalculationMethod;
import com.batoulapps.adhan.CalculationParameters;
import com.batoulapps.adhan.Coordinates;
import com.batoulapps.adhan.Madhab;
import com.batoulapps.adhan.PrayerTimes;
import com.batoulapps.adhan.data.DateComponents;

import java.util.Calendar;
import java.util.Date;

/**
 * محرك حساب مواقيت الصلاة الخمسة والشروق باستخدام مكتبة Adhan الموثوقة.
 *
 * يراعي:
 * 1. عدم احتساب الشروق كصلاة مفروضة في العداد التنازلي (الشروق معلومة مستقلة لانتهاء وقت الفجر).
 * 2. التعامل الدقيق مع ما بعد صلاة العشاء ومنتصف الليل (حساب فجر اليوم التالي تلقائياً).
 * 3. دعم طريقة الهيئة المصرية العامة للمساحة كافتراضي مع طرق الحساب الأخرى ومذهبي الشافعي والحنفي.
 */
public class PrayerTimesHelper {

    public enum ObligatoryPrayer {
        FAJR("الفجر"),
        DHUHR("الظهر"),
        ASR("العصر"),
        MAGHRIB("المغرب"),
        ISHA("العشاء");

        public final String arabicName;

        ObligatoryPrayer(String arabicName) {
            this.arabicName = arabicName;
        }
    }

    public static class DailySchedule {
        public final Date fajr;
        public final Date sunrise;
        public final Date dhuhr;
        public final Date asr;
        public final Date maghrib;
        public final Date isha;
        public final Date tomorrowFajr;

        public final ObligatoryPrayer nextPrayer;
        public final Date nextPrayerTime;
        public final boolean isNextPrayerTomorrowFajr;

        public DailySchedule(
                Date fajr,
                Date sunrise,
                Date dhuhr,
                Date asr,
                Date maghrib,
                Date isha,
                Date tomorrowFajr,
                ObligatoryPrayer nextPrayer,
                Date nextPrayerTime,
                boolean isNextPrayerTomorrowFajr
        ) {
            this.fajr = fajr;
            this.sunrise = sunrise;
            this.dhuhr = dhuhr;
            this.asr = asr;
            this.maghrib = maghrib;
            this.isha = isha;
            this.tomorrowFajr = tomorrowFajr;
            this.nextPrayer = nextPrayer;
            this.nextPrayerTime = nextPrayerTime;
            this.isNextPrayerTomorrowFajr = isNextPrayerTomorrowFajr;
        }

        public long getRemainingMillis(Date now) {
            if (nextPrayerTime == null || now == null) return 0L;
            return Math.max(0L, nextPrayerTime.getTime() - now.getTime());
        }
    }

    public static CalculationParameters buildCalculationParameters(int methodIndex, int madhabIndex) {
        CalculationParameters params;
        switch (methodIndex) {
            case 1:
                params = CalculationMethod.UMM_AL_QURA.getParameters();
                break;
            case 2:
                params = CalculationMethod.MUSLIM_WORLD_LEAGUE.getParameters();
                break;
            case 3:
                params = CalculationMethod.KARACHI.getParameters();
                break;
            case 4:
                params = CalculationMethod.NORTH_AMERICA.getParameters();
                break;
            case 0:
            default:
                // الهيئة المصرية العامة للمساحة (زاوية الفجر 19.5°، زاوية العشاء 17.5°)
                params = CalculationMethod.EGYPTIAN.getParameters();
                break;
        }
        params.madhab = (madhabIndex == 1) ? Madhab.HANAFI : Madhab.SHAFI;
        return params;
    }

    public static String getCalculationMethodNameAr(int methodIndex) {
        switch (methodIndex) {
            case 1:
                return "تقويم أم القرى (مكة المكرمة)";
            case 2:
                return "رابطة العالم الإسلامي";
            case 3:
                return "جامعة العلوم الإسلامية بكراتشي";
            case 4:
                return "الهيئة الإسلامية لأمريكا الشمالية (ISNA)";
            case 0:
            default:
                return "الهيئة المصرية العامة للمساحة (19.5° / 17.5°)";
        }
    }

    public static DailySchedule calculateSchedule(Date now, PrayerPreferences prefs) {
        double lat = prefs.getLatitude();
        double lng = prefs.getLongitude();
        int methodIndex = prefs.getCalculationMethodIndex();
        int madhabIndex = prefs.getAsrMadhabIndex();
        return calculateSchedule(now, lat, lng, methodIndex, madhabIndex);
    }

    public static DailySchedule calculateSchedule(
            Date now,
            double latitude,
            double longitude,
            int methodIndex,
            int madhabIndex
    ) {
        Coordinates coordinates = new Coordinates(latitude, longitude);
        CalculationParameters params = buildCalculationParameters(methodIndex, madhabIndex);

        DateComponents todayComponents = DateComponents.from(now);
        PrayerTimes todayTimes = new PrayerTimes(coordinates, todayComponents, params);

        Calendar tomorrowCal = Calendar.getInstance();
        tomorrowCal.setTime(now);
        tomorrowCal.add(Calendar.DAY_OF_MONTH, 1);
        DateComponents tomorrowComponents = DateComponents.from(tomorrowCal.getTime());
        PrayerTimes tomorrowTimes = new PrayerTimes(coordinates, tomorrowComponents, params);

        Date fajr = todayTimes.fajr;
        Date sunrise = todayTimes.sunrise;
        Date dhuhr = todayTimes.dhuhr;
        Date asr = todayTimes.asr;
        Date maghrib = todayTimes.maghrib;
        Date isha = todayTimes.isha;
        Date tomorrowFajr = tomorrowTimes.fajr;

        // تحديد الصلاة المفروضة القادمة (مع استثناء الشروق لأنه ليس صلاة واجبة)
        ObligatoryPrayer nextPrayer;
        Date nextPrayerTime;
        boolean isTomorrow = false;

        long nowMs = now.getTime();
        if (nowMs < fajr.getTime()) {
            nextPrayer = ObligatoryPrayer.FAJR;
            nextPrayerTime = fajr;
        } else if (nowMs < dhuhr.getTime()) {
            // حتى لو كان الوقت قبل الشروق، الصلاة المفروضة القادمة بعد الفجر هي الظهر
            nextPrayer = ObligatoryPrayer.DHUHR;
            nextPrayerTime = dhuhr;
        } else if (nowMs < asr.getTime()) {
            nextPrayer = ObligatoryPrayer.ASR;
            nextPrayerTime = asr;
        } else if (nowMs < maghrib.getTime()) {
            nextPrayer = ObligatoryPrayer.MAGHRIB;
            nextPrayerTime = maghrib;
        } else if (nowMs < isha.getTime()) {
            nextPrayer = ObligatoryPrayer.ISHA;
            nextPrayerTime = isha;
        } else {
            // بعد صلاة العشاء (قبل منتصف الليل): الصلاة القادمة هي فجر الغد
            nextPrayer = ObligatoryPrayer.FAJR;
            nextPrayerTime = tomorrowFajr;
            isTomorrow = true;
        }

        return new DailySchedule(
                fajr, sunrise, dhuhr, asr, maghrib, isha, tomorrowFajr,
                nextPrayer, nextPrayerTime, isTomorrow
        );
    }
}
