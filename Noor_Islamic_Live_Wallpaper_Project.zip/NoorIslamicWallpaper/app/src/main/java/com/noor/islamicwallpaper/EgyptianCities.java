package com.noor.islamicwallpaper;

import java.util.ArrayList;
import java.util.List;

/**
 * قائمة المدن المصرية المعتمدة مع إحداثياتها الجغرافية الدقيقة (دوائر العرض وخطوط الطول).
 * القاهرة هي المدينة الافتراضية.
 */
public class EgyptianCities {

    public static class City {
        public final String id;
        public final String nameAr;
        public final double latitude;
        public final double longitude;

        public City(String id, String nameAr, double latitude, double longitude) {
            this.id = id;
            this.nameAr = nameAr;
            this.latitude = latitude;
            this.longitude = longitude;
        }
    }

    private static final List<City> CITIES = new ArrayList<>();

    static {
        CITIES.add(new City("cairo", "القاهرة (الافتراضية)", 30.0444, 31.2357));
        CITIES.add(new City("giza", "الجيزة", 30.0131, 31.2089));
        CITIES.add(new City("alexandria", "الإسكندرية", 31.2001, 29.9187));
        CITIES.add(new City("mansoura", "المنصورة", 31.0409, 31.3785));
        CITIES.add(new City("assiut", "أسيوط", 27.1783, 31.1859));
        CITIES.add(new City("aswan", "أسوان", 24.0889, 32.8998));
        CITIES.add(new City("tanta", "طنطا", 30.7865, 31.0004));
        CITIES.add(new City("zagazig", "الزقازيق", 30.5877, 31.5020));
        CITIES.add(new City("damanhour", "دمنهور", 31.0341, 30.4682));
        CITIES.add(new City("portsaid", "بورسعيد", 31.2653, 32.3019));
        CITIES.add(new City("ismailia", "الإسماعيلية", 30.5965, 32.2715));
        CITIES.add(new City("suez", "السويس", 29.9668, 32.5498));
        CITIES.add(new City("shebin", "شبين الكوم", 30.5526, 31.0101));
        CITIES.add(new City("banha", "بنها", 30.4660, 31.1848));
        CITIES.add(new City("kafr_elsheikh", "كفر الشيخ", 31.1107, 30.9388));
        CITIES.add(new City("damietta", "دمياط", 31.4175, 31.8144));
        CITIES.add(new City("fayoum", "الفيوم", 29.3084, 30.8428));
        CITIES.add(new City("beni_suef", "بني سويف", 29.0661, 31.0994));
        CITIES.add(new City("minya", "المنيا", 28.1099, 30.7503));
        CITIES.add(new City("sohag", "سوهاج", 26.5591, 31.6957));
        CITIES.add(new City("qena", "قنا", 26.1551, 32.7160));
        CITIES.add(new City("luxor", "الأقصر", 25.6872, 32.6396));
        CITIES.add(new City("hurghada", "الغردقة", 27.2579, 33.8116));
        CITIES.add(new City("sharm", "شرم الشيخ", 27.9158, 34.3300));
        CITIES.add(new City("matrouh", "مرسى مطروح", 31.3543, 27.2373));
        CITIES.add(new City("arish", "العريش", 31.1321, 33.8033));
        CITIES.add(new City("kharga", "الوادي الجديد (الخارجة)", 25.4390, 30.5586));
    }

    public static List<City> getAllCities() {
        return CITIES;
    }

    public static City getDefaultCity() {
        return CITIES.get(0);
    }

    public static City findByIndex(int index) {
        if (index < 0 || index >= CITIES.size()) {
            return getDefaultCity();
        }
        return CITIES.get(index);
    }

    public static int findIndexById(String id) {
        if (id == null) return 0;
        for (int i = 0; i < CITIES.size(); i++) {
            if (CITIES.get(i).id.equals(id)) {
                return i;
            }
        }
        return 0;
    }
}
