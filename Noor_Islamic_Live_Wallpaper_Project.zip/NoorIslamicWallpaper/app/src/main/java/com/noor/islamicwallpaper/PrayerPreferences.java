package com.noor.islamicwallpaper;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * إدارة وحفظ جميع إعدادات التطبيق في SharedPreferences.
 */
public class PrayerPreferences {

    public static final String PREFS_NAME = "noor_islamic_wallpaper_prefs";

    private static final String KEY_CITY_ID = "city_id";
    private static final String KEY_USE_GPS = "use_gps";
    private static final String KEY_CUSTOM_LAT = "custom_lat";
    private static final String KEY_CUSTOM_LNG = "custom_lng";
    private static final String KEY_CUSTOM_LOCATION_LABEL = "custom_location_label";

    // طرق الحساب: 0 = المصرية العامة للمساحة، 1 = أم القرى، 2 = رابطة العالم الإسلامي، 3 = كراتشي، 4 = أمريكا الشمالية
    private static final String KEY_CALC_METHOD = "calc_method";

    // مذهب العصر: 0 = الشافعي (الجمهور)، 1 = الحنفي
    private static final String KEY_ASR_MADHAB = "asr_madhab";

    // تنسيق الساعة: false = 12 ساعة، true = 24 ساعة
    private static final String KEY_USE_24_HOUR = "use_24_hour";

    // الأرقام: true = أرقام عربية شرقية (٠١٢٣٤٥٦٧٨٩)، false = أرقام إنجليزية (0123456789)
    private static final String KEY_USE_ARABIC_DIGITS = "use_arabic_digits";

    // تعديل التاريخ الهجري باليوم (-2 إلى +2)
    private static final String KEY_HIJRI_OFFSET_DAYS = "hijri_offset_days";

    // إظهار لوحة الساعة والتاريخ والصلاة القادمة داخل الخلفية الحية نفسها
    private static final String KEY_SHOW_WALLPAPER_OVERLAY = "show_wallpaper_overlay";

    private final SharedPreferences prefs;

    public PrayerPreferences(Context context) {
        this.prefs = context.getApplicationContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public String getCityId() {
        return prefs.getString(KEY_CITY_ID, "cairo");
    }

    public void setCityId(String cityId) {
        prefs.edit().putString(KEY_CITY_ID, cityId).putBoolean(KEY_USE_GPS, false).apply();
    }

    public boolean isUseGps() {
        return prefs.getBoolean(KEY_USE_GPS, false);
    }

    public void setGpsLocation(double lat, double lng, String label) {
        prefs.edit()
                .putBoolean(KEY_USE_GPS, true)
                .putString(KEY_CUSTOM_LAT, String.valueOf(lat))
                .putString(KEY_CUSTOM_LNG, String.valueOf(lng))
                .putString(KEY_CUSTOM_LOCATION_LABEL, label != null ? label : "موقعي الحالي (GPS)")
                .apply();
    }

    public double getLatitude() {
        if (isUseGps()) {
            try {
                return Double.parseDouble(prefs.getString(KEY_CUSTOM_LAT, "30.0444"));
            } catch (NumberFormatException e) {
                return 30.0444;
            }
        }
        int idx = EgyptianCities.findIndexById(getCityId());
        return EgyptianCities.findByIndex(idx).latitude;
    }

    public double getLongitude() {
        if (isUseGps()) {
            try {
                return Double.parseDouble(prefs.getString(KEY_CUSTOM_LNG, "31.2357"));
            } catch (NumberFormatException e) {
                return 31.2357;
            }
        }
        int idx = EgyptianCities.findIndexById(getCityId());
        return EgyptianCities.findByIndex(idx).longitude;
    }

    public String getLocationDisplayName() {
        if (isUseGps()) {
            return prefs.getString(KEY_CUSTOM_LOCATION_LABEL, "موقعي الحالي (GPS)");
        }
        int idx = EgyptianCities.findIndexById(getCityId());
        return EgyptianCities.findByIndex(idx).nameAr;
    }

    public int getCalculationMethodIndex() {
        return prefs.getInt(KEY_CALC_METHOD, 0); // 0 = الهيئة المصرية العامة للمساحة افتراضياً
    }

    public void setCalculationMethodIndex(int index) {
        prefs.edit().putInt(KEY_CALC_METHOD, index).apply();
    }

    public int getAsrMadhabIndex() {
        return prefs.getInt(KEY_ASR_MADHAB, 0); // 0 = الشافعي افتراضياً
    }

    public void setAsrMadhabIndex(int index) {
        prefs.edit().putInt(KEY_ASR_MADHAB, index).apply();
    }

    public boolean isUse24Hour() {
        return prefs.getBoolean(KEY_USE_24_HOUR, false); // 12 ساعة افتراضياً
    }

    public void setUse24Hour(boolean use24) {
        prefs.edit().putBoolean(KEY_USE_24_HOUR, use24).apply();
    }

    public boolean isUseArabicDigits() {
        return prefs.getBoolean(KEY_USE_ARABIC_DIGITS, true); // أرقام عربية افتراضياً
    }

    public void setUseArabicDigits(boolean useArabic) {
        prefs.edit().putBoolean(KEY_USE_ARABIC_DIGITS, useArabic).apply();
    }

    public int getHijriOffsetDays() {
        return prefs.getInt(KEY_HIJRI_OFFSET_DAYS, 0);
    }

    public void setHijriOffsetDays(int offsetDays) {
        int clamped = Math.max(-2, Math.min(2, offsetDays));
        prefs.edit().putInt(KEY_HIJRI_OFFSET_DAYS, clamped).apply();
    }

    public boolean isShowWallpaperOverlay() {
        return prefs.getBoolean(KEY_SHOW_WALLPAPER_OVERLAY, true);
    }

    public void setShowWallpaperOverlay(boolean show) {
        prefs.edit().putBoolean(KEY_SHOW_WALLPAPER_OVERLAY, show).apply();
    }

    public void resetToDefaults() {
        prefs.edit().clear().apply();
    }
}
