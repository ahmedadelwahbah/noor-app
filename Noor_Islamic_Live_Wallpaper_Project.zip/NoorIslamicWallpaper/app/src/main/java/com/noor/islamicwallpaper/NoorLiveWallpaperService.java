package com.noor.islamicwallpaper;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.os.Handler;
import android.os.Looper;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

import java.util.Date;

/**
 * خدمة الخلفية الحية الرسمية (Live Wallpaper Service).
 *
 * تراعي:
 * - التوقف الفوري عن الرسم عند إغلاق الشاشة أو فتح تطبيق آخر (visible == false) للحفاظ على البطارية.
 * - الاستماع لتغير الوقت أو المنطقة الزمنية أو إعدادات المستخدم وتحديث حساب مواقيت الصلاة تلقائياً.
 */
public class NoorLiveWallpaperService extends WallpaperService {

    @Override
    public Engine onCreateEngine() {
        return new NoorWallpaperEngine();
    }

    private class NoorWallpaperEngine extends Engine implements SharedPreferences.OnSharedPreferenceChangeListener {

        private final Handler handler = new Handler(Looper.getMainLooper());
        private final SkyRenderer skyRenderer = new SkyRenderer();
        private PrayerPreferences prefs;
        private PrayerTimesHelper.DailySchedule currentSchedule;
        private long lastScheduleCalcMillis = 0L;

        private boolean isVisible = false;
        private int surfaceWidth = 0;
        private int surfaceHeight = 0;

        // معدل التحديث أثناء ظهور الشاشة الرئيسية: كل 1000 مللي ثانية لتحديث الثواني وتلألؤ النجوم بأقل استهلاك للبطارية
        private static final long FRAME_DELAY_MS = 1000L;

        private final Runnable drawRunner = new Runnable() {
            @Override
            public void run() {
                drawFrame();
            }
        };

        private final BroadcastReceiver timeChangeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                lastScheduleCalcMillis = 0L;
                if (isVisible) {
                    drawFrame();
                }
            }
        };

        private boolean receiverRegistered = false;

        @Override
        public void onCreate(SurfaceHolder surfaceHolder) {
            super.onCreate(surfaceHolder);
            prefs = new PrayerPreferences(getApplicationContext());
            getApplicationContext()
                    .getSharedPreferences(PrayerPreferences.PREFS_NAME, Context.MODE_PRIVATE)
                    .registerOnSharedPreferenceChangeListener(this);

            IntentFilter filter = new IntentFilter();
            filter.addAction(Intent.ACTION_TIME_CHANGED);
            filter.addAction(Intent.ACTION_TIMEZONE_CHANGED);
            filter.addAction(Intent.ACTION_DATE_CHANGED);
            filter.addAction(Intent.ACTION_LOCALE_CHANGED);
            getApplicationContext().registerReceiver(timeChangeReceiver, filter);
            receiverRegistered = true;
        }

        @Override
        public void onDestroy() {
            super.onDestroy();
            handler.removeCallbacks(drawRunner);
            getApplicationContext()
                    .getSharedPreferences(PrayerPreferences.PREFS_NAME, Context.MODE_PRIVATE)
                    .unregisterOnSharedPreferenceChangeListener(this);
            if (receiverRegistered) {
                try {
                    getApplicationContext().unregisterReceiver(timeChangeReceiver);
                } catch (Exception ignored) {
                }
                receiverRegistered = false;
            }
        }

        @Override
        public void onVisibilityChanged(boolean visible) {
            this.isVisible = visible;
            if (visible) {
                drawFrame();
            } else {
                // إيقاف الرسم تماماً عند عدم ظهور الخلفية لتوفير البطارية
                handler.removeCallbacks(drawRunner);
            }
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            this.surfaceWidth = width;
            this.surfaceHeight = height;
            if (isVisible) {
                drawFrame();
            }
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            super.onSurfaceDestroyed(holder);
            this.isVisible = false;
            handler.removeCallbacks(drawRunner);
        }

        @Override
        public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
            lastScheduleCalcMillis = 0L;
            if (isVisible) {
                drawFrame();
            }
        }

        private void drawFrame() {
            handler.removeCallbacks(drawRunner);
            if (!isVisible) return;

            SurfaceHolder holder = getSurfaceHolder();
            Canvas canvas = null;
            try {
                canvas = holder.lockCanvas();
                if (canvas != null) {
                    Date now = new Date();
                    if (currentSchedule == null || (now.getTime() - lastScheduleCalcMillis) > 30000L) {
                        currentSchedule = PrayerTimesHelper.calculateSchedule(now, prefs);
                        lastScheduleCalcMillis = now.getTime();
                    }
                    int w = surfaceWidth > 0 ? surfaceWidth : canvas.getWidth();
                    int h = surfaceHeight > 0 ? surfaceHeight : canvas.getHeight();
                    skyRenderer.render(canvas, w, h, now, currentSchedule, prefs, true);
                }
            } catch (Exception ignored) {
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas);
                    } catch (Exception ignored) {
                    }
                }
            }

            if (isVisible) {
                handler.postDelayed(drawRunner, FRAME_DELAY_MS);
            }
        }
    }
}
