package com.noor.islamicwallpaper;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.widget.RemoteViews;

import java.util.Date;

/**
 * أداة الشاشة الرئيسية (Home Screen Widget) لعرض الساعة العربية،
 * التاريخ الهجري والميلادي، والصلاة القادمة فوق الشاشة الرئيسية.
 */
public class NoorAppWidgetProvider extends AppWidgetProvider {

    public static final String ACTION_REFRESH_WIDGET = "com.noor.islamicwallpaper.ACTION_REFRESH_WIDGET";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateSingleWidget(context, appWidgetManager, appWidgetId);
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (intent != null && ACTION_REFRESH_WIDGET.equals(intent.getAction())) {
            updateAllWidgets(context);
        }
    }

    public static void updateAllWidgets(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName componentName = new ComponentName(context, NoorAppWidgetProvider.class);
        int[] ids = manager.getAppWidgetIds(componentName);
        if (ids != null && ids.length > 0) {
            for (int id : ids) {
                updateSingleWidget(context, manager, id);
            }
        }
    }

    private static void updateSingleWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        PrayerPreferences prefs = new PrayerPreferences(context);
        Date now = new Date();
        PrayerTimesHelper.DailySchedule schedule = PrayerTimesHelper.calculateSchedule(now, prefs);

        boolean use24 = prefs.isUse24Hour();
        boolean useArDigits = prefs.isUseArabicDigits();
        int hijriOffset = prefs.getHijriOffsetDays();

        String timeText = DateAndFormatHelper.formatTime(now, use24, useArDigits);
        String dayName = DateAndFormatHelper.getDayOfWeekNameAr(now);
        String hijriDate = DateAndFormatHelper.getHijriDateFull(now, hijriOffset, useArDigits);
        String gregDate = DateAndFormatHelper.getGregorianDateFull(now, useArDigits);
        String nextPrayerName = schedule.nextPrayer.arabicName;
        String nextPrayerTime = DateAndFormatHelper.formatTime(schedule.nextPrayerTime, use24, useArDigits);

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_noor);
        views.setTextViewText(R.id.widget_clock_text, timeText);
        views.setTextViewText(R.id.widget_hijri_text, dayName + " • " + hijriDate);
        views.setTextViewText(R.id.widget_gregorian_text, gregDate + " • " + prefs.getLocationDisplayName());
        views.setTextViewText(
                R.id.widget_next_prayer_text,
                "الصلاة القادمة: " + nextPrayerName + " (" + nextPrayerTime + ")"
        );

        // عند الضغط على الويدجت يفتح التطبيق الرئيسي
        Intent launchIntent = new Intent(context, MainActivity.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, launchIntent, flags);
        views.setOnClickPendingIntent(R.id.widget_root_container, pendingIntent);

        appWidgetManager.updateAppWidget(appWidgetId, views);
    }
}
