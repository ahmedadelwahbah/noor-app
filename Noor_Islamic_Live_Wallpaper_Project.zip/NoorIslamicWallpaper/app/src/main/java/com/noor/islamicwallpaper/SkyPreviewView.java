package com.noor.islamicwallpaper;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;

import java.util.Calendar;
import java.util.Date;

/**
 * عنصر معاينة حي داخل واجهة التطبيق يعرض مشهد الخلفية الحية الحقيقي
 * ويسمح للمستخدم بمعاينة شكل السماء وحركة الشمس والقمر في الوقت الحقيقي أو عبر شريط تمرير الساعات.
 */
public class SkyPreviewView extends View {

    private final SkyRenderer renderer = new SkyRenderer();
    private PrayerPreferences prefs;
    private PrayerTimesHelper.DailySchedule cachedSchedule;
    private int cachedDayOfYear = -1;

    // -1 يعني عرض الوقت الحقيقي؛ من 0 إلى 1439 يعني معاينة دقيقة محددة من اليوم
    private int previewOverrideMinutes = -1;

    public SkyPreviewView(Context context) {
        super(context);
        init(context);
    }

    public SkyPreviewView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public SkyPreviewView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        this.prefs = new PrayerPreferences(context);
    }

    public void setPreviewOverrideMinutes(int minutesOfDay) {
        this.previewOverrideMinutes = minutesOfDay;
        invalidate();
    }

    public int getPreviewOverrideMinutes() {
        return previewOverrideMinutes;
    }

    public void invalidateSchedule() {
        this.cachedDayOfYear = -1;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Date renderTime = new Date();
        if (previewOverrideMinutes >= 0 && previewOverrideMinutes < 1440) {
            Calendar cal = Calendar.getInstance();
            cal.setTime(renderTime);
            cal.set(Calendar.HOUR_OF_DAY, previewOverrideMinutes / 60);
            cal.set(Calendar.MINUTE, previewOverrideMinutes % 60);
            cal.set(Calendar.SECOND, 0);
            renderTime = cal.getTime();
        }

        Calendar calNow = Calendar.getInstance();
        calNow.setTime(renderTime);
        int doy = calNow.get(Calendar.DAY_OF_YEAR);

        if (cachedSchedule == null || doy != cachedDayOfYear || previewOverrideMinutes >= 0) {
            cachedSchedule = PrayerTimesHelper.calculateSchedule(renderTime, prefs);
            cachedDayOfYear = doy;
        }

        renderer.render(canvas, getWidth(), getHeight(), renderTime, cachedSchedule, prefs, true);
    }
}
