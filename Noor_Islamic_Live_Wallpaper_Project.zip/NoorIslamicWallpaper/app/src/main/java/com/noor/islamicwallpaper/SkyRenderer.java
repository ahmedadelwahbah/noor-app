package com.noor.islamicwallpaper;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

import java.util.Calendar;
import java.util.Date;

/**
 * محرك الرسم الرسومي المشترك للخلفية الحية والمعاينة داخل التطبيق.
 * يرسم:
 * 1. تدرج السماء المتغير بسلاسة حسب أوقات الفجر والشروق والظهر والعصر والغروب والعشاء.
 * 2. النجوم المتلألئة ليلاً مع التحكم في شدة سطوعها.
 * 3. الشمس وحركتها القوسية الواقعية بين الشروق والغروب مع الوهج والانعكاس الدافئ.
 * 4. القمر وحركته الليلية وطوره الحقيقي (هلال / بدر / تربيع) مع ضوء القمر.
 * 5. الأفق الطبيعي والمسجد الإسلامي بالقباب والأهلة والمآذن والنوافذ المضيئة ليلاً.
 * 6. بطاقة الساعة والتاريخ والصلاة القادمة الاختيارية في أعلى الشاشة دون حجب المشهد.
 */
public class SkyRenderer {

    private final Paint skyPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint starPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint sunGlowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint sunCorePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint moonGlowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint moonPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint moonShadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint horizonGlowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hillBackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hillFrontPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mosquePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint goldAccentPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint windowLightPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final Paint overlayBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint overlayBorderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint clockTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dateTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint prayerTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final Path hillBackPath = new Path();
    private final Path hillFrontPath = new Path();
    private final Path mosquePath = new Path();
    private final RectF tempRect = new RectF();

    // مواقع النجوم الثابتة نسبياً (70 نجمة) لتجنب إنشاء كائنات أثناء الرسم
    private static final int STAR_COUNT = 70;
    private final float[] starX = new float[STAR_COUNT];
    private final float[] starY = new float[STAR_COUNT];
    private final float[] starSize = new float[STAR_COUNT];
    private final float[] starPhase = new float[STAR_COUNT];

    public SkyRenderer() {
        // توليد مواقع نجوم متناسقة باستخدام دالة حتمية
        for (int i = 0; i < STAR_COUNT; i++) {
            starX[i] = (float) ((Math.sin(i * 12.9898 + 78.233) * 43758.5453) - Math.floor(Math.sin(i * 12.9898 + 78.233) * 43758.5453));
            starY[i] = (float) ((Math.sin(i * 93.9898 + 12.456) * 23421.6312) - Math.floor(Math.sin(i * 93.9898 + 12.456) * 23421.6312)) * 0.62f + 0.03f;
            starSize[i] = 1.8f + (i % 4) * 0.9f;
            starPhase[i] = i * 0.75f;
        }

        goldAccentPaint.setColor(0xFFD4AF37);
        goldAccentPaint.setStyle(Paint.Style.FILL);

        overlayBgPaint.setColor(0x66081026);
        overlayBgPaint.setStyle(Paint.Style.FILL);

        overlayBorderPaint.setColor(0x66D4AF37);
        overlayBorderPaint.setStyle(Paint.Style.STROKE);
        overlayBorderPaint.setStrokeWidth(2.5f);

        clockTextPaint.setColor(0xFFFDFBF7);
        clockTextPaint.setTextAlign(Paint.Align.CENTER);
        clockTextPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));

        dateTextPaint.setColor(0xFFE6D5B8);
        dateTextPaint.setTextAlign(Paint.Align.CENTER);

        prayerTextPaint.setColor(0xFFFFD166);
        prayerTextPaint.setTextAlign(Paint.Align.CENTER);
        prayerTextPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
    }

    /**
     * رسم المشهد الكامل على الـ Canvas.
     */
    public void render(
            Canvas canvas,
            int width,
            int height,
            Date currentTime,
            PrayerTimesHelper.DailySchedule schedule,
            PrayerPreferences prefs,
            boolean drawOverlayCard
    ) {
        if (width <= 0 || height <= 0 || schedule == null || currentTime == null) return;

        float density = Math.max(1f, width / 400f);

        // حساب الدقائق منذ بداية اليوم (مع الكسور للثواني لضمان النعومة)
        Calendar cal = Calendar.getInstance();
        cal.setTime(currentTime);
        float nowMinutes = cal.get(Calendar.HOUR_OF_DAY) * 60f
                + cal.get(Calendar.MINUTE)
                + cal.get(Calendar.SECOND) / 60f;

        float fajrMin = toMinutesOfDay(schedule.fajr);
        float sunriseMin = toMinutesOfDay(schedule.sunrise);
        float dhuhrMin = toMinutesOfDay(schedule.dhuhr);
        float asrMin = toMinutesOfDay(schedule.asr);
        float maghribMin = toMinutesOfDay(schedule.maghrib);
        float ishaMin = toMinutesOfDay(schedule.isha);

        // 1. حساب ألوان السماء المتدرجة (أعلى، وسط، أفق)
        int[] skyColors = computeSkyGradientColors(nowMinutes, fajrMin, sunriseMin, dhuhrMin, asrMin, maghribMin, ishaMin);
        LinearGradient skyGrad = new LinearGradient(
                0, 0, 0, height * 0.85f,
                new int[]{skyColors[0], skyColors[1], skyColors[2]},
                new float[]{0f, 0.52f, 1f},
                Shader.TileMode.CLAMP
        );
        skyPaint.setShader(skyGrad);
        canvas.drawRect(0, 0, width, height, skyPaint);

        // 2. حساب معامل الليل (0 نهاراً -> 1 ليلاً)
        float nightFactor = computeNightFactor(nowMinutes, fajrMin, sunriseMin, maghribMin, ishaMin);

        // 3. رسم النجوم المتلألئة ليلاً وعند الشفق
        if (nightFactor > 0.02f) {
            float animSec = (currentTime.getTime() % 600000L) / 1000f;
            for (int i = 0; i < STAR_COUNT; i++) {
                float twinkle = 0.55f + 0.45f * (float) Math.sin(animSec * 2.2f + starPhase[i]);
                int alpha = Math.min(255, Math.max(0, (int) (255f * nightFactor * twinkle)));
                starPaint.setColor(Color.argb(alpha, 255, 250, 235));
                float sx = starX[i] * width;
                float sy = starY[i] * height;
                canvas.drawCircle(sx, sy, starSize[i] * density * 0.55f, starPaint);
            }
        }

        // 4. رسم توهج الأفق الدافئ عند الشروق والغروب
        float sunsetGlowFactor = computeHorizonWarmGlow(nowMinutes, fajrMin, sunriseMin, maghribMin, ishaMin);
        if (sunsetGlowFactor > 0.01f) {
            int glowAlpha = (int) (185 * sunsetGlowFactor);
            int glowColor = Color.argb(glowAlpha, 255, 130, 65);
            RadialGradient horizonGrad = new RadialGradient(
                    width * 0.5f, height * 0.78f,
                    width * 0.85f,
                    glowColor, Color.TRANSPARENT,
                    Shader.TileMode.CLAMP
            );
            horizonGlowPaint.setShader(horizonGrad);
            canvas.drawRect(0, height * 0.25f, width, height * 0.85f, horizonGlowPaint);
        }

        // 5. رسم الشمس وحركتها الواقعية نهاراً
        if (nowMinutes >= fajrMin - 10f && nowMinutes <= maghribMin + 25f) {
            drawSun(canvas, width, height, density, nowMinutes, sunriseMin, dhuhrMin, maghribMin, prefs.getLatitude(), currentTime);
        }

        // 6. رسم القمر وطوره الحقيقي ليلاً
        if (nightFactor > 0.05f) {
            drawMoon(canvas, width, height, density, nowMinutes, fajrMin, maghribMin, nightFactor, currentTime, prefs.getHijriOffsetDays());
        }

        // 7. رسم التلال الخلفية والمسجد الإسلامي والمآذن في الأفق
        drawHorizonAndMosque(canvas, width, height, density, nightFactor, sunsetGlowFactor);

        // 8. رسم بطاقة الساعة والتاريخ والصلاة القادمة في أعلى الخلفية الحية (إذا كانت مفعّلة)
        if (drawOverlayCard && prefs.isShowWallpaperOverlay()) {
            drawTopOverlay(canvas, width, height, density, currentTime, schedule, prefs);
        }
    }

    private void drawSun(
            Canvas canvas,
            int width,
            int height,
            float density,
            float nowMinutes,
            float sunriseMin,
            float dhuhrMin,
            float maghribMin,
            double latitude,
            Date currentTime
    ) {
        float daySpan = Math.max(60f, maghribMin - sunriseMin);
        float progress = (nowMinutes - sunriseMin) / daySpan; // 0 عند الشروق -> 1 عند الغروب
        float clampedProgress = Math.max(-0.08f, Math.min(1.08f, progress));

        // تتحرك الشمس من الشرق (اليمين) إلى الغرب (اليسار) في قوس طبيعي
        float sunX = width * (0.86f - clampedProgress * 0.72f);

        float horizonY = height * 0.76f;
        float maxAltitudeDeg = AstronomyHelper.getMaxSolarNoonAltitudeDegrees(latitude, currentTime);
        float maxArcHeight = height * (0.36f + (maxAltitudeDeg / 90f) * 0.14f);

        // منحنى الارتفاع الجيبي بين الشروق والغروب
        float altitudeFactor = (float) Math.sin(Math.PI * clampedProgress);
        float sunY = horizonY - altitudeFactor * maxArcHeight;

        float sunRadius = 24f * density;
        float glowRadius = sunRadius * 4.2f;

        // لون الشمس يتدرج من البرتقالي الذهبي عند الأفق إلى الأبيض الذهبي الساطع ظهراً
        float warmth = 1f - Math.max(0f, Math.min(1f, altitudeFactor));
        int coreColor = evaluateColor(warmth, 0xFFFFFDE7, 0xFFFF9E44);
        int innerGlow = evaluateColor(warmth, 0x99FFF59D, 0xAAFF7043);

        RadialGradient glowGrad = new RadialGradient(
                sunX, sunY, glowRadius,
                new int[]{innerGlow, 0x33FFB74D, Color.TRANSPARENT},
                new float[]{0.15f, 0.55f, 1.0f},
                Shader.TileMode.CLAMP
        );
        sunGlowPaint.setShader(glowGrad);
        canvas.drawCircle(sunX, sunY, glowRadius, sunGlowPaint);

        sunCorePaint.setColor(coreColor);
        canvas.drawCircle(sunX, sunY, sunRadius, sunCorePaint);
    }

    private void drawMoon(
            Canvas canvas,
            int width,
            int height,
            float density,
            float nowMinutes,
            float fajrMin,
            float maghribMin,
            float nightFactor,
            Date currentTime,
            int hijriOffsetDays
    ) {
        // حساب تقدم الليل من المغرب (0.0) إلى فجر اليوم التالي (1.0)
        float totalNightSpan = (1440f - maghribMin) + fajrMin;
        if (totalNightSpan <= 60f) totalNightSpan = 600f;

        float elapsedNight;
        if (nowMinutes >= maghribMin) {
            elapsedNight = nowMinutes - maghribMin;
        } else {
            elapsedNight = (1440f - maghribMin) + nowMinutes;
        }
        float nightProgress = Math.max(0f, Math.min(1f, elapsedNight / totalNightSpan));

        // مسار القمر في السماء الليلية
        float moonX = width * (0.82f - nightProgress * 0.64f);
        float horizonY = height * 0.74f;
        float arcHeight = height * 0.44f;
        float moonY = horizonY - (float) Math.sin(Math.PI * nightProgress) * arcHeight;

        float moonRadius = 21f * density;
        float glowRadius = moonRadius * 3.8f;

        int glowAlpha = (int) (130 * nightFactor);
        RadialGradient moonGlow = new RadialGradient(
                moonX, moonY, glowRadius,
                Color.argb(glowAlpha, 210, 230, 255),
                Color.TRANSPARENT,
                Shader.TileMode.CLAMP
        );
        moonGlowPaint.setShader(moonGlow);
        canvas.drawCircle(moonX, moonY, glowRadius, moonGlowPaint);

        // رسم القمر الأساسي المضيء
        int moonAlpha = (int) (255 * nightFactor);
        moonPaint.setColor(Color.argb(moonAlpha, 248, 244, 227));
        canvas.drawCircle(moonX, moonY, moonRadius, moonPaint);

        // محاكاة طور القمر الحقيقي (هلال / تربيع / بدر) برسم ظل القمر
        float phase = AstronomyHelper.getMoonPhase(currentTime.getTime(), hijriOffsetDays);
        // عند البدر (phase ~ 0.5) يبتعد الظل تماماً، وعند الهلال يقترب الظل ليترك الهلال مضيئاً
        float distanceFromFull = Math.abs(phase - 0.5f) * 2f; // 0 = بدر كامل، 1 = محاق
        if (distanceFromFull > 0.08f) {
            float shadowOffset = moonRadius * (1.85f * (1f - distanceFromFull));
            if (phase < 0.5f) {
                shadowOffset = -shadowOffset; // الهلال في أول الشهر
            }
            moonShadowPaint.setColor(Color.argb((int) (235 * nightFactor), 12, 20, 44));
            canvas.drawCircle(moonX + shadowOffset, moonY - moonRadius * 0.05f, moonRadius * 0.96f, moonShadowPaint);
        }
    }

    private void drawHorizonAndMosque(
            Canvas canvas,
            int width,
            int height,
            float density,
            float nightFactor,
            float sunsetGlowFactor
    ) {
        float baseHorizonY = height * 0.80f;

        // تلال خلفية متدرجة
        int hillBackColor = evaluateColor(nightFactor, 0xFF1F3A5F, 0xFF0A1124);
        if (sunsetGlowFactor > 0.1f) {
            hillBackColor = evaluateColor(sunsetGlowFactor * 0.6f, hillBackColor, 0xFF3D1E3A);
        }
        hillBackPaint.setColor(hillBackColor);

        hillBackPath.reset();
        hillBackPath.moveTo(0, height);
        hillBackPath.lineTo(0, baseHorizonY - 22f * density);
        hillBackPath.quadTo(width * 0.28f, baseHorizonY - 58f * density, width * 0.55f, baseHorizonY - 18f * density);
        hillBackPath.quadTo(width * 0.80f, baseHorizonY + 12f * density, width, baseHorizonY - 30f * density);
        hillBackPath.lineTo(width, height);
        hillBackPath.close();
        canvas.drawPath(hillBackPath, hillBackPaint);

        // تلال أمامية
        int hillFrontColor = evaluateColor(nightFactor, 0xFF142742, 0xFF060A17);
        hillFrontPaint.setColor(hillFrontColor);

        hillFrontPath.reset();
        hillFrontPath.moveTo(0, height);
        hillFrontPath.lineTo(0, baseHorizonY + 8f * density);
        hillFrontPath.quadTo(width * 0.35f, baseHorizonY - 18f * density, width * 0.70f, baseHorizonY + 6f * density);
        hillFrontPath.quadTo(width * 0.88f, baseHorizonY + 18f * density, width, baseHorizonY - 4f * density);
        hillFrontPath.lineTo(width, height);
        hillFrontPath.close();
        canvas.drawPath(hillFrontPath, hillFrontPaint);

        // رسم المسجد الإسلامي في الأفق السفلي
        int mosqueColor = evaluateColor(nightFactor, 0xFF0D1B2E, 0xFF040711);
        mosquePaint.setColor(mosqueColor);

        float centerX = width * 0.5f;
        float groundY = baseHorizonY + 15f * density;

        // قاعدة المسجد الرئيسية
        float baseWidth = width * 0.64f;
        float baseHeight = 46f * density;
        canvas.drawRect(centerX - baseWidth / 2f, groundY - baseHeight, centerX + baseWidth / 2f, height, mosquePaint);

        // القبة الرئيسية الوسطى
        float mainDomeRadius = 48f * density;
        float mainDomeCenterY = groundY - baseHeight;
        tempRect.set(
                centerX - mainDomeRadius,
                mainDomeCenterY - mainDomeRadius * 1.15f,
                centerX + mainDomeRadius,
                mainDomeCenterY + mainDomeRadius * 0.5f
        );
        canvas.drawArc(tempRect, 180f, 180f, true, mosquePaint);

        // قبتان جانبيتان
        float sideDomeRadius = 27f * density;
        float leftDomeX = centerX - mainDomeRadius * 1.38f;
        float rightDomeX = centerX + mainDomeRadius * 1.38f;

        tempRect.set(leftDomeX - sideDomeRadius, mainDomeCenterY - sideDomeRadius * 1.05f, leftDomeX + sideDomeRadius, mainDomeCenterY + sideDomeRadius * 0.4f);
        canvas.drawArc(tempRect, 180f, 180f, true, mosquePaint);

        tempRect.set(rightDomeX - sideDomeRadius, mainDomeCenterY - sideDomeRadius * 1.05f, rightDomeX + sideDomeRadius, mainDomeCenterY + sideDomeRadius * 0.4f);
        canvas.drawArc(tempRect, 180f, 180f, true, mosquePaint);

        // المئذنتان (اليسرى واليمنى)
        float minaretOffset = width * 0.34f;
        float minaretWidth = 13f * density;
        float minaretHeight = 142f * density;
        drawMinaret(canvas, centerX - minaretOffset, groundY, minaretWidth, minaretHeight, density);
        drawMinaret(canvas, centerX + minaretOffset, groundY, minaretWidth, minaretHeight, density);

        // هلال القبة الرئيسية باللون الذهبي
        float finialTopY = mainDomeCenterY - mainDomeRadius * 1.15f - 14f * density;
        goldAccentPaint.setStrokeWidth(2.2f * density);
        canvas.drawLine(centerX, mainDomeCenterY - mainDomeRadius * 1.05f, centerX, finialTopY + 5f * density, goldAccentPaint);
        drawGoldenCrescent(canvas, centerX, finialTopY, 6.5f * density);

        // نوافذ المسجد المضيئة باللون الذهبي الدافئ عند الغروب والليل
        float windowGlow = Math.max(nightFactor, sunsetGlowFactor * 0.75f);
        if (windowGlow > 0.15f) {
            int winAlpha = (int) (220 * windowGlow);
            windowLightPaint.setColor(Color.argb(winAlpha, 255, 212, 102));
            int windowCount = 7;
            float spacing = (baseWidth * 0.78f) / windowCount;
            float startX = centerX - (baseWidth * 0.39f) + spacing * 0.5f;
            float winW = 7.5f * density;
            float winH = 16f * density;
            float winBottom = groundY - 12f * density;

            for (int i = 0; i < windowCount; i++) {
                float wx = startX + i * spacing;
                tempRect.set(wx - winW / 2f, winBottom - winH, wx + winW / 2f, winBottom);
                canvas.drawRoundRect(tempRect, winW / 2f, winW / 2f, windowLightPaint);
            }
        }
    }

    private void drawMinaret(Canvas canvas, float x, float groundY, float width, float height, float density) {
        float halfW = width / 2f;
        float topY = groundY - height;
        // جسم المئذنة
        canvas.drawRect(x - halfW, topY + 26f * density, x + halfW, groundY, mosquePaint);
        // شرفة المئذنة الأولى والثانية
        canvas.drawRect(x - halfW * 1.55f, topY + 52f * density, x + halfW * 1.55f, topY + 58f * density, mosquePaint);
        canvas.drawRect(x - halfW * 1.45f, topY + 24f * density, x + halfW * 1.45f, topY + 30f * density, mosquePaint);
        // قمة المئذنة المخروطية/القبة الصغيرة
        mosquePath.reset();
        mosquePath.moveTo(x - halfW * 0.85f, topY + 24f * density);
        mosquePath.lineTo(x, topY);
        mosquePath.lineTo(x + halfW * 0.85f, topY + 24f * density);
        mosquePath.close();
        canvas.drawPath(mosquePath, mosquePaint);

        // هلال المئذنة الذهبي
        drawGoldenCrescent(canvas, x, topY - 6f * density, 4.5f * density);
    }

    private void drawGoldenCrescent(Canvas canvas, float cx, float cy, float radius) {
        canvas.drawCircle(cx, cy, radius, goldAccentPaint);
    }

    private void drawTopOverlay(
            Canvas canvas,
            int width,
            int height,
            float density,
            Date currentTime,
            PrayerTimesHelper.DailySchedule schedule,
            PrayerPreferences prefs
    ) {
        boolean use24 = prefs.isUse24Hour();
        boolean useArDigits = prefs.isUseArabicDigits();
        int hijriOffset = prefs.getHijriOffsetDays();

        String timeStr = DateAndFormatHelper.formatTime(currentTime, use24, useArDigits);
        String dayName = DateAndFormatHelper.getDayOfWeekNameAr(currentTime);
        String hijriStr = DateAndFormatHelper.getHijriDateFull(currentTime, hijriOffset, useArDigits);
        String gregStr = DateAndFormatHelper.getGregorianDateFull(currentTime, useArDigits);

        String nextPrayerName = schedule.nextPrayer.arabicName;
        String nextPrayerTimeStr = DateAndFormatHelper.formatTime(schedule.nextPrayerTime, use24, useArDigits);
        String countdownStr = DateAndFormatHelper.formatCountdown(schedule.getRemainingMillis(currentTime), useArDigits);

        float cardMarginH = width * 0.06f;
        float cardTop = height * 0.08f;
        float cardHeight = 118f * density;
        tempRect.set(cardMarginH, cardTop, width - cardMarginH, cardTop + cardHeight);

        canvas.drawRoundRect(tempRect, 18f * density, 18f * density, overlayBgPaint);
        canvas.drawRoundRect(tempRect, 18f * density, 18f * density, overlayBorderPaint);

        float centerX = width * 0.5f;

        clockTextPaint.setTextSize(28f * density);
        canvas.drawText(timeStr, centerX, cardTop + 36f * density, clockTextPaint);

        dateTextPaint.setTextSize(12.5f * density);
        canvas.drawText(dayName + " • " + hijriStr, centerX, cardTop + 62f * density, dateTextPaint);
        canvas.drawText(gregStr + " • " + prefs.getLocationDisplayName(), centerX, cardTop + 82f * density, dateTextPaint);

        prayerTextPaint.setTextSize(13.5f * density);
        String nextLine = "الصلاة القادمة: " + nextPrayerName + " (" + nextPrayerTimeStr + ") - متبقي " + countdownStr;
        canvas.drawText(nextLine, centerX, cardTop + 105f * density, prayerTextPaint);
    }

    private float toMinutesOfDay(Date date) {
        if (date == null) return 0f;
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        return c.get(Calendar.HOUR_OF_DAY) * 60f + c.get(Calendar.MINUTE) + c.get(Calendar.SECOND) / 60f;
    }

    private float computeNightFactor(float nowMin, float fajrMin, float sunriseMin, float maghribMin, float ishaMin) {
        if (nowMin >= ishaMin || nowMin <= fajrMin) {
            return 1.0f;
        }
        if (nowMin > sunriseMin + 20f && nowMin < maghribMin - 20f) {
            return 0.0f;
        }
        if (nowMin > fajrMin && nowMin <= sunriseMin + 20f) {
            float span = Math.max(1f, (sunriseMin + 20f) - fajrMin);
            return 1.0f - ((nowMin - fajrMin) / span);
        }
        if (nowMin >= maghribMin - 20f && nowMin < ishaMin) {
            float span = Math.max(1f, ishaMin - (maghribMin - 20f));
            return (nowMin - (maghribMin - 20f)) / span;
        }
        return 0.0f;
    }

    private float computeHorizonWarmGlow(float nowMin, float fajrMin, float sunriseMin, float maghribMin, float ishaMin) {
        // توهج دافئ حول الشروق والغروب
        float distSunrise = Math.abs(nowMin - sunriseMin);
        if (distSunrise < 45f) {
            return 1.0f - (distSunrise / 45f);
        }
        float distSunset = Math.abs(nowMin - maghribMin);
        if (distSunset < 50f) {
            return 1.0f - (distSunset / 50f);
        }
        return 0.0f;
    }

    private int[] computeSkyGradientColors(
            float nowMin,
            float fajrMin,
            float sunriseMin,
            float dhuhrMin,
            float asrMin,
            float maghribMin,
            float ishaMin
    ) {
        // لوحات ألوان المراحل الزمنية (أعلى، وسط، أفق)
        int[] night = {0xFF050814, 0xFF0B152E, 0xFF162447};
        int[] fajr = {0xFF0D1530, 0xFF2E295E, 0xFF8B4F70};
        int[] sunrise = {0xFF1B3B6F, 0xFF4A78C2, 0xFFF4A261};
        int[] morning = {0xFF1565C0, 0xFF42A5F5, 0xFFAEDFF7};
        int[] noon = {0xFF0D47A1, 0xFF1E88E5, 0xFF90CAF9};
        int[] asr = {0xFF1A5276, 0xFF488FB1, 0xFFF5CBA7};
        int[] maghrib = {0xFF1B1947, 0xFF7D3865, 0xFFE76F51};

        if (nowMin < fajrMin) {
            return night;
        } else if (nowMin < sunriseMin) {
            float f = (nowMin - fajrMin) / Math.max(1f, sunriseMin - fajrMin);
            return interpolatePalette(f, fajr, sunrise);
        } else if (nowMin < sunriseMin + 75f) {
            float f = (nowMin - sunriseMin) / 75f;
            return interpolatePalette(f, sunrise, morning);
        } else if (nowMin < dhuhrMin) {
            float f = (nowMin - (sunriseMin + 75f)) / Math.max(1f, dhuhrMin - (sunriseMin + 75f));
            return interpolatePalette(f, morning, noon);
        } else if (nowMin < asrMin) {
            float f = (nowMin - dhuhrMin) / Math.max(1f, asrMin - dhuhrMin);
            return interpolatePalette(f, noon, asr);
        } else if (nowMin < maghribMin) {
            float f = (nowMin - asrMin) / Math.max(1f, maghribMin - asrMin);
            return interpolatePalette(f, asr, maghrib);
        } else if (nowMin < ishaMin) {
            float f = (nowMin - maghribMin) / Math.max(1f, ishaMin - maghribMin);
            return interpolatePalette(f, maghrib, night);
        } else {
            return night;
        }
    }

    private int[] interpolatePalette(float fraction, int[] start, int[] end) {
        float clamped = Math.max(0f, Math.min(1f, fraction));
        return new int[]{
                evaluateColor(clamped, start[0], end[0]),
                evaluateColor(clamped, start[1], end[1]),
                evaluateColor(clamped, start[2], end[2])
        };
    }

    public static int evaluateColor(float fraction, int startColor, int endColor) {
        float f = Math.max(0f, Math.min(1f, fraction));
        int startA = (startColor >> 24) & 0xff;
        int startR = (startColor >> 16) & 0xff;
        int startG = (startColor >> 8) & 0xff;
        int startB = startColor & 0xff;

        int endA = (endColor >> 24) & 0xff;
        int endR = (endColor >> 16) & 0xff;
        int endG = (endColor >> 8) & 0xff;
        int endB = endColor & 0xff;

        return ((startA + (int) (f * (endA - startA))) << 24)
                | ((startR + (int) (f * (endR - startR))) << 16)
                | ((startG + (int) (f * (endG - startG))) << 8)
                | (startB + (int) (f * (endB - startB)));
    }
}
