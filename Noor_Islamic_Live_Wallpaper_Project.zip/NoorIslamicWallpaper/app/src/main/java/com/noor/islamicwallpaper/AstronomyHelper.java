package com.noor.islamicwallpaper;

import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * حسابات فلكية مساعدة لموقع الشمس وارتفاعها في السماء، وطور القمر (الإضاءة الفعلية) وحركته الليلية.
 *
 * ملاحظة تقنية شفافة:
 * - موضع الشمس في الخلفية الحية يُحسب بناءً على وقت الشروق والغروب الحقيقيين للموقع الجغرافي،
 *   مقروناً بزاوية ميل الشمس (Solar Declination) وخط العرض لحساب أقصى ارتفاع للشمس وقت الظهر.
 * - طور القمر (هلال / تربيع / بدر / محاق) يُحسب فلكياً من الدورة القمرية الاقترانية (29.530588 يوماً) والتاريخ الهجري.
 * - موضع القمر في سماء الخلفية الحية ليلاً يتبع مساراً قوسياً مرتبطاً بالوقت الفعلي بين الغروب والفجر
 *   ليظل القمر مرئياً بشكل جمالي في الخلفية طوال الليل.
 */
public class AstronomyHelper {

    private static final double SYNODIC_MONTH = 29.530588853;
    // مرجع محاق فلكي معروف (6 يناير 2000 الساعة 18:14 UTC -> Julian Day 2451550.1)
    private static final double KNOWN_NEW_MOON_JD = 2451550.1;

    /**
     * حساب اليوم اليولياني (Julian Day) من الطابع الزمني.
     */
    public static double toJulianDay(long timeMillis) {
        return (timeMillis / 86400000.0) + 2440587.5;
    }

    /**
     * حساب طور القمر الفلكي (0.0 = محاق، 0.25 = تربيع أول، 0.5 = بدر كامل، 0.75 = تربيع أخير).
     */
    public static float getMoonPhase(long timeMillis, int hijriOffsetDays) {
        long adjustedMillis = timeMillis + (hijriOffsetDays * 86400000L);
        double jd = toJulianDay(adjustedMillis);
        double daysSinceNew = jd - KNOWN_NEW_MOON_JD;
        double cycles = daysSinceNew / SYNODIC_MONTH;
        double phase = cycles - Math.floor(cycles);
        if (phase < 0) phase += 1.0;
        return (float) phase;
    }

    /**
     * حساب نسبة إضاءة قرص القمر (0.0 إلى 1.0).
     */
    public static float getMoonIlluminationFraction(float moonPhase) {
        return (float) ((1.0 - Math.cos(2.0 * Math.PI * moonPhase)) / 2.0);
    }

    /**
     * حساب زاوية ارتفاع الشمس القصوى وقت الظهر (بالدرجات 0°..90°) حسب خط العرض ويوم السنة.
     */
    public static float getMaxSolarNoonAltitudeDegrees(double latitude, Date date) {
        Calendar cal = Calendar.getInstance(TimeZone.getDefault());
        cal.setTime(date);
        int dayOfYear = cal.get(Calendar.DAY_OF_YEAR);
        // زاوية ميل الشمس التقريبية
        double declination = 23.45 * Math.sin(Math.toRadians((360.0 / 365.0) * (dayOfYear - 81)));
        double noonAltitude = 90.0 - Math.abs(latitude - declination);
        return (float) Math.max(20.0, Math.min(88.0, noonAltitude));
    }
}
