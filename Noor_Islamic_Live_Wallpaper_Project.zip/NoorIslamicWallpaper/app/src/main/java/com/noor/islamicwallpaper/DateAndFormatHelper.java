package com.noor.islamicwallpaper;

import android.icu.util.IslamicCalendar;
import android.icu.util.ULocale;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * تنسيق الساعة (12/24)، تحويل الأرقام (عربية/إنجليزية)،
 * وحساب التاريخ الميلادي والهجري مع دعم التعديل اليدوي باليوم (-2 إلى +2).
 */
public class DateAndFormatHelper {

    private static final char[] ARABIC_DIGITS = {'٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'};

    private static final String[] HIJRI_MONTHS_AR = {
            "محرم",
            "صفر",
            "ربيع الأول",
            "ربيع الآخر",
            "جمادى الأولى",
            "جمادى الآخرة",
            "رجب",
            "شعبان",
            "رمضان",
            "شوال",
            "ذو القعدة",
            "ذو الحجة"
    };

    private static final String[] GREGORIAN_MONTHS_AR = {
            "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
            "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
    };

    private static final String[] DAYS_OF_WEEK_AR = {
            "الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"
    };

    /**
     * تحويل الأرقام في النص إلى أرقام عربية شرقية أو إنجليزية حسب اختيار المستخدم.
     */
    public static String formatDigits(String input, boolean useArabicDigits) {
        if (input == null) return "";
        StringBuilder sb = new StringBuilder(input.length());
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (useArabicDigits) {
                if (c >= '0' && c <= '9') {
                    sb.append(ARABIC_DIGITS[c - '0']);
                } else {
                    sb.append(c);
                }
            } else {
                if (c >= '٠' && c <= '٩') {
                    sb.append((char) ('0' + (c - '٠')));
                } else {
                    sb.append(c);
                }
            }
        }
        return sb.toString();
    }

    /**
     * تنسيق الوقت (الساعة والدقيقة) لـ Date معين.
     */
    public static String formatTime(Date date, boolean use24Hour, boolean useArabicDigits) {
        if (date == null) return "--:--";
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int hour24 = cal.get(Calendar.HOUR_OF_DAY);
        int minute = cal.get(Calendar.MINUTE);

        String formatted;
        if (use24Hour) {
            formatted = String.format(Locale.US, "%02d:%02d", hour24, minute);
        } else {
            int hour12 = hour24 % 12;
            if (hour12 == 0) hour12 = 12;
            String amPm = (hour24 < 12) ? "ص" : "م";
            formatted = String.format(Locale.US, "%02d:%02d %s", hour12, minute, amPm);
        }
        return formatDigits(formatted, useArabicDigits);
    }

    /**
     * تنسيق الساعة الرئيسية مع الثواني الاختيارية.
     */
    public static String formatClockWithSeconds(Date date, boolean use24Hour, boolean useArabicDigits) {
        if (date == null) return "--:--:--";
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int hour24 = cal.get(Calendar.HOUR_OF_DAY);
        int minute = cal.get(Calendar.MINUTE);
        int second = cal.get(Calendar.SECOND);

        String formatted;
        if (use24Hour) {
            formatted = String.format(Locale.US, "%02d:%02d:%02d", hour24, minute, second);
        } else {
            int hour12 = hour24 % 12;
            if (hour12 == 0) hour12 = 12;
            String amPm = (hour24 < 12) ? "ص" : "م";
            formatted = String.format(Locale.US, "%02d:%02d:%02d %s", hour12, minute, second, amPm);
        }
        return formatDigits(formatted, useArabicDigits);
    }

    /**
     * تنسيق العد التنازلي بالساعات والدقائق والثواني (HH:MM:SS).
     */
    public static String formatCountdown(long remainingMillis, boolean useArabicDigits) {
        if (remainingMillis < 0) remainingMillis = 0;
        long totalSeconds = remainingMillis / 1000L;
        long hours = totalSeconds / 3600L;
        long minutes = (totalSeconds % 3600L) / 60L;
        long seconds = totalSeconds % 60L;
        String raw = String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds);
        return formatDigits(raw, useArabicDigits);
    }

    /**
     * اسم اليوم باللغة العربية (الأحد، الإثنين...).
     */
    public static String getDayOfWeekNameAr(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int dow = cal.get(Calendar.DAY_OF_WEEK); // 1 = Sunday .. 7 = Saturday
        return DAYS_OF_WEEK_AR[(dow - 1) % 7];
    }

    /**
     * التاريخ الميلادي الكامل باللغة العربية.
     */
    public static String getGregorianDateFull(Date date, boolean useArabicDigits) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int day = cal.get(Calendar.DAY_OF_MONTH);
        int month = cal.get(Calendar.MONTH); // 0..11
        int year = cal.get(Calendar.YEAR);
        String raw = day + " " + GREGORIAN_MONTHS_AR[month] + " " + year + " م";
        return formatDigits(raw, useArabicDigits);
    }

    /**
     * التاريخ الهجري الكامل مع اسم الشهر الهجري بالعربية، مع تطبيق تعديل الأيام اليدوي.
     * يستخدم تقويم أم القرى المدمج في نظام أندرويد (IslamicCalendar) مع تنبيه المستخدم بإمكانية ضبط اليوم حسب الرؤية.
     */
    public static String getHijriDateFull(Date date, int offsetDays, boolean useArabicDigits) {
        try {
            Calendar adjusted = Calendar.getInstance();
            adjusted.setTime(date);
            if (offsetDays != 0) {
                adjusted.add(Calendar.DAY_OF_MONTH, offsetDays);
            }

            ULocale uLocale = new ULocale("@calendar=islamic-umalqura");
            IslamicCalendar islamicCal = new IslamicCalendar(uLocale);
            islamicCal.setTime(adjusted.getTime());

            int hDay = islamicCal.get(android.icu.util.Calendar.DAY_OF_MONTH);
            int hMonth = islamicCal.get(android.icu.util.Calendar.MONTH); // 0..11
            int hYear = islamicCal.get(android.icu.util.Calendar.YEAR);

            String monthName = (hMonth >= 0 && hMonth < HIJRI_MONTHS_AR.length)
                    ? HIJRI_MONTHS_AR[hMonth]
                    : "";

            String raw = hDay + " " + monthName + " " + hYear + " هـ";
            return formatDigits(raw, useArabicDigits);
        } catch (Exception e) {
            // في حال حدوث أي استثناء غير متوقع، نستخدم التقويم الإسلامي القياسي
            IslamicCalendar fallback = new IslamicCalendar();
            fallback.setTime(new Date(date.getTime() + offsetDays * 86400000L));
            int hDay = fallback.get(android.icu.util.Calendar.DAY_OF_MONTH);
            int hMonth = fallback.get(android.icu.util.Calendar.MONTH);
            int hYear = fallback.get(android.icu.util.Calendar.YEAR);
            String monthName = (hMonth >= 0 && hMonth < HIJRI_MONTHS_AR.length)
                    ? HIJRI_MONTHS_AR[hMonth]
                    : "";
            return formatDigits(hDay + " " + monthName + " " + hYear + " هـ", useArabicDigits);
        }
    }

    /**
     * إرجاع اليوم الهجري (1..30) لحساب طور القمر التقريبي عند الحاجة.
     */
    public static int getHijriDayOfMonth(Date date, int offsetDays) {
        try {
            ULocale uLocale = new ULocale("@calendar=islamic-umalqura");
            IslamicCalendar islamicCal = new IslamicCalendar(uLocale);
            islamicCal.setTime(new Date(date.getTime() + offsetDays * 86400000L));
            return islamicCal.get(android.icu.util.Calendar.DAY_OF_MONTH);
        } catch (Exception e) {
            return 15;
        }
    }
}
