package com.noor.islamicwallpaper;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.WallpaperManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * الواجهة الرئيسية لتطبيق «نور – ثيم الصلاة التفاعلي».
 * مصممة بالكامل من اليمين إلى اليسار (RTL) بألوان الكحلي والذهبي.
 */
public class MainActivity extends Activity {

    private static final int REQ_LOCATION_PERMISSION = 1001;

    private PrayerPreferences prefs;
    private final Handler timerHandler = new Handler(Looper.getMainLooper());

    // عناصر المعاينة الحية
    private SkyPreviewView skyPreviewView;
    private SeekBar seekPreviewTime;
    private TextView tvPreviewTimeLabel;
    private Button btnResetPreviewTime;

    // عناصر الساعة والتاريخ
    private TextView tvMainClock;
    private TextView tvDayAndHijri;
    private TextView tvGregorianDate;
    private TextView tvCurrentLocationName;

    // عناصر الصلاة القادمة والعداد التنازلي
    private TextView tvNextPrayerName;
    private TextView tvNextPrayerCountdown;

    // صفوف ومواقيت الصلوات الستة
    private LinearLayout rowFajr, rowSunrise, rowDhuhr, rowAsr, rowMaghrib, rowIsha;
    private TextView tvFajrTime, tvSunriseTime, tvDhuhrTime, tvAsrTime, tvMaghribTime, tvIshaTime;

    // عناصر إعدادات الموقع وطريقة الحساب
    private Spinner spinnerCity;
    private Button btnDetectGps;
    private Spinner spinnerCalcMethod;
    private Spinner spinnerAsrMadhab;

    // عناصر تخصيص الساعة والتاريخ الهجري
    private CheckBox cbUse24Hour;
    private CheckBox cbUseArabicDigits;
    private CheckBox cbShowWallpaperOverlay;
    private TextView tvHijriOffsetValue;
    private Button btnHijriMinus, btnHijriPlus;

    private boolean isInitializingUi = true;

    private final Runnable tickRunnable = new Runnable() {
        @Override
        public void run() {
            updateAllDisplayedData();
            timerHandler.postDelayed(this, 1000L);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = new PrayerPreferences(this);
        bindViews();
        setupSpinnersAndControls();
        isInitializingUi = false;
        updateAllDisplayedData();
    }

    @Override
    protected void onResume() {
        super.onResume();
        timerHandler.removeCallbacks(tickRunnable);
        timerHandler.post(tickRunnable);
    }

    @Override
    protected void onPause() {
        super.onPause();
        timerHandler.removeCallbacks(tickRunnable);
    }

    private void bindViews() {
        skyPreviewView = findViewById(R.id.sky_preview_view);
        seekPreviewTime = findViewById(R.id.seek_preview_time);
        tvPreviewTimeLabel = findViewById(R.id.tv_preview_time_label);
        btnResetPreviewTime = findViewById(R.id.btn_reset_preview_time);

        tvMainClock = findViewById(R.id.tv_main_clock);
        tvDayAndHijri = findViewById(R.id.tv_day_and_hijri);
        tvGregorianDate = findViewById(R.id.tv_gregorian_date);
        tvCurrentLocationName = findViewById(R.id.tv_current_location_name);

        tvNextPrayerName = findViewById(R.id.tv_next_prayer_name);
        tvNextPrayerCountdown = findViewById(R.id.tv_next_prayer_countdown);

        rowFajr = findViewById(R.id.row_fajr);
        rowSunrise = findViewById(R.id.row_sunrise);
        rowDhuhr = findViewById(R.id.row_dhuhr);
        rowAsr = findViewById(R.id.row_asr);
        rowMaghrib = findViewById(R.id.row_maghrib);
        rowIsha = findViewById(R.id.row_isha);

        tvFajrTime = findViewById(R.id.tv_fajr_time);
        tvSunriseTime = findViewById(R.id.tv_sunrise_time);
        tvDhuhrTime = findViewById(R.id.tv_dhuhr_time);
        tvAsrTime = findViewById(R.id.tv_asr_time);
        tvMaghribTime = findViewById(R.id.tv_maghrib_time);
        tvIshaTime = findViewById(R.id.tv_isha_time);

        spinnerCity = findViewById(R.id.spinner_city);
        btnDetectGps = findViewById(R.id.btn_detect_gps);
        spinnerCalcMethod = findViewById(R.id.spinner_calc_method);
        spinnerAsrMadhab = findViewById(R.id.spinner_asr_madhab);

        cbUse24Hour = findViewById(R.id.cb_use_24_hour);
        cbUseArabicDigits = findViewById(R.id.cb_use_arabic_digits);
        cbShowWallpaperOverlay = findViewById(R.id.cb_show_wallpaper_overlay);
        tvHijriOffsetValue = findViewById(R.id.tv_hijri_offset_value);
        btnHijriMinus = findViewById(R.id.btn_hijri_minus);
        btnHijriPlus = findViewById(R.id.btn_hijri_plus);

        Button btnSetLiveWallpaper = findViewById(R.id.btn_set_live_wallpaper);
        Button btnWidgetAndOppoHelp = findViewById(R.id.btn_widget_and_oppo_help);
        Button btnResetSettings = findViewById(R.id.btn_reset_settings);

        btnSetLiveWallpaper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLiveWallpaperPicker();
            }
        });

        btnWidgetAndOppoHelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showOppoAndWidgetGuideDialog();
            }
        });

        btnResetSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmResetSettings();
            }
        });
    }

    private void setupSpinnersAndControls() {
        // 1. شريط تمرير معاينة أوقات اليوم (0..1439 دقيقة)
        seekPreviewTime.setMax(1439);
        seekPreviewTime.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    skyPreviewView.setPreviewOverrideMinutes(progress);
                    int h = progress / 60;
                    int m = progress % 60;
                    String t = String.format(Locale.US, "%02d:%02d", h, m);
                    tvPreviewTimeLabel.setText("وضع المعاينة التجريبية للساعة: " + DateAndFormatHelper.formatDigits(t, prefs.isUseArabicDigits()));
                    btnResetPreviewTime.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        btnResetPreviewTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                skyPreviewView.setPreviewOverrideMinutes(-1);
                tvPreviewTimeLabel.setText("المعاينة تعرض الوقت الحقيقي الآن (حرك الشريط لتجربة النهار والليل)");
                btnResetPreviewTime.setVisibility(View.GONE);
            }
        });

        // 2. قائمة المدن المصرية
        List<EgyptianCities.City> cities = EgyptianCities.getAllCities();
        List<String> cityNames = new ArrayList<>();
        for (EgyptianCities.City c : cities) {
            cityNames.add(c.nameAr);
        }
        ArrayAdapter<String> cityAdapter = new ArrayAdapter<>(this, R.layout.item_spinner, cityNames);
        cityAdapter.setDropDownViewResource(R.layout.item_spinner_dropdown);
        spinnerCity.setAdapter(cityAdapter);
        spinnerCity.setSelection(EgyptianCities.findIndexById(prefs.getCityId()));

        spinnerCity.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (isInitializingUi) return;
                EgyptianCities.City selected = EgyptianCities.findByIndex(position);
                prefs.setCityId(selected.id);
                onSettingsUpdated();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        // 3. زر تحديد الموقع عبر GPS
        btnDetectGps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestGpsLocation();
            }
        });

        // 4. قائمة طرق الحساب
        String[] methods = new String[]{
                "الهيئة المصرية العامة للمساحة (19.5° / 17.5°)",
                "تقويم أم القرى (مكة المكرمة)",
                "رابطة العالم الإسلامي",
                "جامعة العلوم الإسلامية بكراتشي",
                "الهيئة الإسلامية لأمريكا الشمالية (ISNA)"
        };
        ArrayAdapter<String> methodAdapter = new ArrayAdapter<>(this, R.layout.item_spinner, methods);
        methodAdapter.setDropDownViewResource(R.layout.item_spinner_dropdown);
        spinnerCalcMethod.setAdapter(methodAdapter);
        spinnerCalcMethod.setSelection(prefs.getCalculationMethodIndex());

        spinnerCalcMethod.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (isInitializingUi) return;
                prefs.setCalculationMethodIndex(position);
                onSettingsUpdated();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        // 5. مذهب العصر
        String[] madhabs = new String[]{
                "المذهب الشافعي والجمهور (ظل المثل - الافتراضي لمصر)",
                "المذهب الحنفي (ظل المثلين)"
        };
        ArrayAdapter<String> madhabAdapter = new ArrayAdapter<>(this, R.layout.item_spinner, madhabs);
        madhabAdapter.setDropDownViewResource(R.layout.item_spinner_dropdown);
        spinnerAsrMadhab.setAdapter(madhabAdapter);
        spinnerAsrMadhab.setSelection(prefs.getAsrMadhabIndex());

        spinnerAsrMadhab.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (isInitializingUi) return;
                prefs.setAsrMadhabIndex(position);
                onSettingsUpdated();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        // 6. خيارات الساعة والأرقام والتاريخ الهجري
        cbUse24Hour.setChecked(prefs.isUse24Hour());
        cbUse24Hour.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isInitializingUi) return;
                prefs.setUse24Hour(isChecked);
                onSettingsUpdated();
            }
        });

        cbUseArabicDigits.setChecked(prefs.isUseArabicDigits());
        cbUseArabicDigits.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isInitializingUi) return;
                prefs.setUseArabicDigits(isChecked);
                onSettingsUpdated();
            }
        });

        cbShowWallpaperOverlay.setChecked(prefs.isShowWallpaperOverlay());
        cbShowWallpaperOverlay.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isInitializingUi) return;
                prefs.setShowWallpaperOverlay(isChecked);
                onSettingsUpdated();
            }
        });

        btnHijriMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int current = prefs.getHijriOffsetDays();
                if (current > -2) {
                    prefs.setHijriOffsetDays(current - 1);
                    onSettingsUpdated();
                } else {
                    Toast.makeText(MainActivity.this, "الحد الأقصى للتعديل هو يومان (-2 إلى +2)", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnHijriPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int current = prefs.getHijriOffsetDays();
                if (current < 2) {
                    prefs.setHijriOffsetDays(current + 1);
                    onSettingsUpdated();
                } else {
                    Toast.makeText(MainActivity.this, "الحد الأقصى للتعديل هو يومان (-2 إلى +2)", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void onSettingsUpdated() {
        skyPreviewView.invalidateSchedule();
        updateAllDisplayedData();
        NoorAppWidgetProvider.updateAllWidgets(this);
    }

    private void updateAllDisplayedData() {
        Date now = new Date();
        PrayerTimesHelper.DailySchedule schedule = PrayerTimesHelper.calculateSchedule(now, prefs);

        boolean use24 = prefs.isUse24Hour();
        boolean useAr = prefs.isUseArabicDigits();
        int hijriOffset = prefs.getHijriOffsetDays();

        // تحديث الساعة والتاريخ
        tvMainClock.setText(DateAndFormatHelper.formatClockWithSeconds(now, use24, useAr));
        String dayName = DateAndFormatHelper.getDayOfWeekNameAr(now);
        String hijriStr = DateAndFormatHelper.getHijriDateFull(now, hijriOffset, useAr);
        tvDayAndHijri.setText(dayName + " • " + hijriStr);
        tvGregorianDate.setText(DateAndFormatHelper.getGregorianDateFull(now, useAr));

        String locInfo = String.format(Locale.US, "%s (%.2f°N, %.2f°E)",
                prefs.getLocationDisplayName(), prefs.getLatitude(), prefs.getLongitude());
        tvCurrentLocationName.setText("الموقع الحالي: " + DateAndFormatHelper.formatDigits(locInfo, useAr));

        // تحديث الصلاة القادمة والعداد التنازلي
        String nextLabel = "الصلاة المفروضة القادمة: " + schedule.nextPrayer.arabicName
                + (schedule.isNextPrayerTomorrowFajr ? " (غداً)" : "")
                + " • " + DateAndFormatHelper.formatTime(schedule.nextPrayerTime, use24, useAr);
        tvNextPrayerName.setText(nextLabel);

        String countdown = DateAndFormatHelper.formatCountdown(schedule.getRemainingMillis(now), useAr);
        tvNextPrayerCountdown.setText("الوقت المتبقي: " + countdown);

        // تحديث جدول المواقيت
        tvFajrTime.setText(DateAndFormatHelper.formatTime(schedule.fajr, use24, useAr));
        tvSunriseTime.setText(DateAndFormatHelper.formatTime(schedule.sunrise, use24, useAr));
        tvDhuhrTime.setText(DateAndFormatHelper.formatTime(schedule.dhuhr, use24, useAr));
        tvAsrTime.setText(DateAndFormatHelper.formatTime(schedule.asr, use24, useAr));
        tvMaghribTime.setText(DateAndFormatHelper.formatTime(schedule.maghrib, use24, useAr));
        tvIshaTime.setText(DateAndFormatHelper.formatTime(schedule.isha, use24, useAr));

        // تمييز صف الصلاة القادمة باللون الذهبي (مع عدم احتساب الشروق صلاة مفروضة)
        highlightActivePrayerRow(schedule.nextPrayer);

        // تحديث نص تعديل التاريخ الهجري
        String offsetStr;
        if (hijriOffset == 0) {
            offsetStr = "بدون تعديل (٠ يوم)";
        } else if (hijriOffset > 0) {
            offsetStr = "+" + hijriOffset + " يوم";
        } else {
            offsetStr = hijriOffset + " يوم";
        }
        tvHijriOffsetValue.setText(DateAndFormatHelper.formatDigits(offsetStr, useAr));

        // تحديث المعاينة الحية
        skyPreviewView.invalidate();
    }

    private void highlightActivePrayerRow(PrayerTimesHelper.ObligatoryPrayer next) {
        rowFajr.setBackgroundResource(next == PrayerTimesHelper.ObligatoryPrayer.FAJR ? R.drawable.card_highlight_background : R.drawable.card_background);
        rowSunrise.setBackgroundResource(R.drawable.card_background); // الشروق معلومة مستقلة وليس صلاة واجبة
        rowDhuhr.setBackgroundResource(next == PrayerTimesHelper.ObligatoryPrayer.DHUHR ? R.drawable.card_highlight_background : R.drawable.card_background);
        rowAsr.setBackgroundResource(next == PrayerTimesHelper.ObligatoryPrayer.ASR ? R.drawable.card_highlight_background : R.drawable.card_background);
        rowMaghrib.setBackgroundResource(next == PrayerTimesHelper.ObligatoryPrayer.MAGHRIB ? R.drawable.card_highlight_background : R.drawable.card_background);
        rowIsha.setBackgroundResource(next == PrayerTimesHelper.ObligatoryPrayer.ISHA ? R.drawable.card_highlight_background : R.drawable.card_background);
    }

    /**
     * طلب صلاحية الموقع الجغرافي وقت الحاجة فقط.
     * إذا رفض المستخدم أو كان الـ GPS مغلقاً، يستمر التطبيق في العمل دون أي تعطل.
     */
    private void requestGpsLocation() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
                        REQ_LOCATION_PERMISSION
                );
                return;
            }
        }
        fetchLastKnownLocation();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION_PERMISSION) {
            boolean granted = false;
            if (grantResults != null) {
                for (int res : grantResults) {
                    if (res == PackageManager.PERMISSION_GRANTED) {
                        granted = true;
                        break;
                    }
                }
            }
            if (granted) {
                fetchLastKnownLocation();
            } else {
                Toast.makeText(
                        this,
                        "لم يتم منح إذن الموقع. يستمر التطبيق في العمل باستخدام المدينة المختارة يدوياً (" + prefs.getLocationDisplayName() + ").",
                        Toast.LENGTH_LONG
                ).show();
            }
        }
    }

    private void fetchLastKnownLocation() {
        try {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (lm == null) {
                Toast.makeText(this, "خدمة الموقع غير متاحة، تم الإبقاء على المدينة المختارة.", Toast.LENGTH_SHORT).show();
                return;
            }
            Location bestLocation = null;
            List<String> providers = lm.getProviders(true);
            for (String provider : providers) {
                try {
                    Location l = lm.getLastKnownLocation(provider);
                    if (l != null) {
                        if (bestLocation == null || l.getAccuracy() < bestLocation.getAccuracy()) {
                            bestLocation = l;
                        }
                    }
                } catch (SecurityException ignored) {
                }
            }

            if (bestLocation != null) {
                prefs.setGpsLocation(bestLocation.getLatitude(), bestLocation.getLongitude(), "موقعي الحالي (GPS)");
                onSettingsUpdated();
                Toast.makeText(this, "تم تحديث الموقع الجغرافي وحساب المواقيت بنجاح.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(
                        this,
                        "تأكد من تفعيل الـ GPS في الهاتف، أو استخدم اختيار المدينة يدوياً من القائمة.",
                        Toast.LENGTH_LONG
                ).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "تعذر قراءة الـ GPS، يعمل التطبيق على المدينة المختارة.", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * فتح شاشة معاينة وتعيين الخلفية الحية في أندرويد مع بدائل متوافقة مع هواتف OPPO (ColorOS 13).
     */
    private void openLiveWallpaperPicker() {
        try {
            Intent intent = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
            intent.putExtra(
                    WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    new ComponentName(this, NoorLiveWallpaperService.class)
            );
            startActivity(intent);
        } catch (ActivityNotFoundException e1) {
            try {
                Intent chooser = new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER);
                startActivity(chooser);
            } catch (ActivityNotFoundException e2) {
                try {
                    Intent setWall = new Intent(Intent.ACTION_SET_WALLPAPER);
                    startActivity(Intent.createChooser(setWall, "اختر الخلفية الحية"));
                } catch (Exception e3) {
                    Toast.makeText(
                            this,
                            "يرجى فتح إعدادات الهاتف > التخصيص > الخلفيات > الخلفيات الحية واختيار (نور – ثيم الصلاة التفاعلي).",
                            Toast.LENGTH_LONG
                    ).show();
                }
            }
        }
    }

    private void showOppoAndWidgetGuideDialog() {
        String message = "١. طريقة إضافة أداة الشاشة الرئيسية (Widget) على هاتف OPPO:
"
                + "• اضغط مطولاً في مكان فارغ على الشاشة الرئيسية للهاتف.
"
                + "• اختر «الأدوات» أو «Widgets» من الشريط السفلي.
"
                + "• ابحث عن «نور – ثيم الصلاة التفاعلي» واسحب الأداة إلى شاشتك الرئيسية.

"
                + "٢. نصيحة مهمة لهواتف OPPO (نظام ColorOS / Android 13):
"
                + "• لضمان استمرار تحديث العداد التنازلي والـ Widget في الخلفية دون إيقاف من النظام، افتح: إعدادات الهاتف > البطارية > إعدادات إضافية > تحسين استخدام البطارية > اختر «نور» وحدد «عدم التحسين».

"
                + "٣. ملاحظة حول الخلفية الحية والويدجت:
"
                + "• الخلفية الحية مسؤولة عن مشهد السماء والشمس والقمر والمسجد (ويمكنك أيضاً تفعيل أو إخفاء نص الساعة أعلى الخلفية الحية من الإعدادات بالأسفل)، بينما الويدجت هي الأداة التفاعلية المستقلة التي توضع فوق الشاشة الرئيسية وتفتح التطبيق عند لمسها.";

        new AlertDialog.Builder(this)
                .setTitle("دليل الاستخدام وإرشادات هواتف OPPO")
                .setMessage(message)
                .setPositiveButton("حسناً، فهمت", null)
                .show();
    }

    private void confirmResetSettings() {
        new AlertDialog.Builder(this)
                .setTitle("إعادة ضبط الإعدادات")
                .setMessage("هل تريد استعادة جميع الإعدادات الافتراضية (القاهرة، الهيئة المصرية العامة للمساحة، المذهب الشافعي، نظام 12 ساعة، والأرقام العربية)؟")
                .setPositiveButton("نعم، إعادة ضبط", (dialog, which) -> {
                    prefs.resetToDefaults();
                    isInitializingUi = true;
                    spinnerCity.setSelection(0);
                    spinnerCalcMethod.setSelection(0);
                    spinnerAsrMadhab.setSelection(0);
                    cbUse24Hour.setChecked(prefs.isUse24Hour());
                    cbUseArabicDigits.setChecked(prefs.isUseArabicDigits());
                    cbShowWallpaperOverlay.setChecked(prefs.isShowWallpaperOverlay());
                    skyPreviewView.setPreviewOverrideMinutes(-1);
                    btnResetPreviewTime.setVisibility(View.GONE);
                    tvPreviewTimeLabel.setText("المعاينة تعرض الوقت الحقيقي الآن (حرك الشريط لتجربة النهار والليل)");
                    isInitializingUi = false;
                    onSettingsUpdated();
                    Toast.makeText(MainActivity.this, "تمت استعادة الإعدادات الافتراضية بنجاح.", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }
}
