# نور – ثيم الصلاة التفاعلي (Noor Interactive Islamic Live Wallpaper)

مشروع أندرويد أصلي ومتكامل متوافق مع **Android 13 (API 33)** وهواتف **OPPO (ColorOS 13)**، يعمل بالكامل بدون إنترنت أو خوادم خارجية.

---

## أولاً: طريقة تحويل المشروع إلى ملف APK وتثبيته من هاتفك فقط (بدون كمبيوتر)

بما أنك تعمل من هاتف OPPO مباشرةً ولا تملك جهاز كمبيوتر، تم تجهيز المشروع بملف بناء سحابي تلقائي (`.github/workflows/build-apk.yml`) وبنية قياسية متوافقة مع تطبيقات البناء على الهاتف. إليك أسهل طريقتين:

### الطريقة الأولى (الأسهل والأسرع – بدون استهلاك مساحة الهاتف عبر GitHub Actions مجاناً)
1. افتح متصفح **Chrome** على هاتفك وادخل إلى موقع [github.com](https://github.com) وسجّل الدخول (أو أنشئ حساباً مجانياً).
2. اضغط على علامة **(+)** في الأعلى واختر **New repository**، وسمِّ المستودع مثلاً `noor-wallpaper` ثم اضغط **Create repository**.
3. فك الضغط عن ملف `Noor_Islamic_Live_Wallpaper_Project.zip` على هاتفك باستخدام تطبيق **مدير الملفات** في هاتف OPPO (أو تطبيق ZArchiver).
4. ارفع ملفات المشروع إلى المستودع (أو استخدم تطبيق **GitHub** أو **Spck Editor** على الهاتف لرفع المجلد).
5. بمجرد رفع الملفات، ادخل إلى تبويب **Actions** في صفحة المستودع على GitHub، ثم اختر **Build Noor Android APK** واضغط **Run workflow**.
6. خلال دقيقتين فقط، سيكتمل البناء باللون الأخضر ✅، وستجد في أسفل الصفحة تحت قسم **Artifacts** ملف **`Noor-Islamic-Live-Wallpaper-APK`**، اضغط عليه لتحميل ملف `app-debug.apk` وتثبيته مباشرة على هاتفك!

### الطريقة الثانية (البناء محلياً على الهاتف نفسه باستخدام تطبيق AndroidIDE)
1. ثبّت تطبيق **AndroidIDE** (المخصص لمعالجات الهواتف arm64 ونظام Android 13) من موقعه الرسمي.
2. فك ضغط ملف `Noor_Islamic_Live_Wallpaper_Project.zip` في مجلد مشاريع الهاتف.
3. افتح المشروع من داخل **AndroidIDE** واضغط على زر **Build / Run (▶️)** في الأعلى، وسيقوم التطبيق بتوليد ملف `app-debug.apk` وتثبيته على هاتفك فوراً.

---

## ثانياً: مواصفات وإصدارات المشروع المتوافقة
- **Package Name:** `com.noor.islamicwallpaper`
- **Compile & Target SDK:** `33` (Android 13)
- **Min SDK:** `26` (Android 8.0+)
- **Android Gradle Plugin (AGP):** `8.1.4`
- **Gradle Version:** `8.2.1`
- **Java Version:** `17`
- **مكتبة مواقيت الصلاة:** `com.batoulapps.adhan:adhan:1.2.1` (المكتبة الرسمية المعتمدة في Maven Central).

---

## ثالثاً: هيكل ملفات المشروع الكامل
```text
NoorIslamicWallpaper/
├── .github/workflows/build-apk.yml       # ملف البناء التلقائي لاستخراج APK من متصفح الهاتف
├── build.gradle                          # إعدادات Gradle الجذرية
├── settings.gradle                       # إعدادات المستودعات والمشروع
├── gradle.properties                     # خصائص الذاكرة والتوافق
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle                      # إعدادات تطبيق أندرويد ومكتبة Adhan
    ├── proguard-rules.pro                # قواعد الحفاظ على الكلاسات
    └── src/main/
        ├── AndroidManifest.xml           # تعريف التطبيق، الخلفية الحية، الويدجت، والصلاحيات
        ├── java/com/noor/islamicwallpaper/
        │   ├── MainActivity.java              # الواجهة الرئيسية، المعاينة، الإعدادات، والمواقيت
        │   ├── NoorLiveWallpaperService.java  # خدمة الخلفية الحية الرسمية WallpaperService
        │   ├── SkyRenderer.java               # محرك رسم السماء، الشمس، القمر، النجوم، والمسجد
        │   ├── SkyPreviewView.java            # عنصر المعاينة التفاعلية الحية داخل التطبيق
        │   ├── PrayerTimesHelper.java         # حساب المواقيت الخمسة والشروق والعداد التنازلي
        │   ├── AstronomyHelper.java           # حساب ارتفاع الشمس وطور القمر الفلكي
        │   ├── DateAndFormatHelper.java       # التقويم الهجري والميلادي وتنسيق الساعة والأرقام
        │   ├── EgyptianCities.java            # قائمة المدن المصرية وإحداثياتها الدقيقة
        │   ├── PrayerPreferences.java         # حفظ واسترجاع الإعدادات
        │   ├── NoorAppWidgetProvider.java     # أداة الشاشة الرئيسية (Widget)
        │   └── BootAndTimeReceiver.java       # تحديث الويدجت والمواقيت عند تغير الوقت أو إعادة التشغيل
        └── res/
            ├── drawable/                 # الخلفيات، الأيقونات، والبطاقات الذهبية والكحلية
            ├── layout/                   # تصميم الشاشة الرئيسية (activity_main) والويدجت (widget_noor)
            ├── mipmap-anydpi-v26/        # أيقونة التطبيق المتكيفة (Adaptive Icon)
            ├── values/                   # النصوص العربية، الألوان، والسمات
            └── xml/                      # إعدادات الخلفية الحية والويدجت والنسخ الاحتياطي
```
